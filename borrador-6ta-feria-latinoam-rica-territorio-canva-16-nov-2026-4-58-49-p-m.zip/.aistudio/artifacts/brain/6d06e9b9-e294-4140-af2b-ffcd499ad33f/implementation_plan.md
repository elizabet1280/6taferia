# Portal de Acceso Verificado, Control por IP/Dispositivos y Panel Admin · 6ta Feria Territorio Canva

Sistema de puerta de acceso exclusiva para alumnas inscritas en la 6ta Feria Territorio Canva mediante validación de correo y código único de compra en Supabase, soporte para hasta **2 dispositivos del mismo país/red**, bloqueo automático con alerta ante uso compartido (exceso de dispositivos o países distintos como EE. UU. y Venezuela), bóveda local de credenciales de aula virtual y apartado de administrador protegido con clave y credenciales recordables.

---

### Revisión del Usuario y Decisiones Críticas

> [!IMPORTANT]
> Confirma si esta versión ajustada cumple exactamente con lo que necesitas:
> 1. **Regla confirmada de hasta 2 dispositivos + control de IP y país**:
>    - Cada alumna puede ingresar hasta en **2 dispositivos personales** (por ejemplo, laptop y celular).
>    - Caminar por la casa (habitación → cocina) mantiene la misma IP pública y país, y usar datos móviles dentro del mismo país también es compatible dentro del límite de 2 dispositivos.
>    - Si un dispositivo intenta entrar desde **otro país distinto al autorizado** (por ejemplo, uno en Venezuela y otro en EE. UU.) o si se intenta registrar un **3.er dispositivo**, el acceso se bloquea al instante y se emite la alerta indicando cuántos dispositivos y ubicaciones se han detectado.
>    - *Nota operativa*: Si una alumna tiene una VPN activa en otro país, se activará el bloqueo preventivo; desde el panel administrador podrás restablecer su ubicación en un clic.
> 2. **Apartado de Administrador con clave y guardado de credenciales**:
>    - Acceso protegido por **clave de administrador verificada en Supabase**.
>    - Opción en el dispositivo del profesor para **guardar sus credenciales de administrador** y entrar rápidamente a consultar alertas, autorizar cambios de equipo o cargar/guardar las credenciales y códigos de compra de cada alumna.
> 3. **Puerta directa a `aulavirtual-premium.com`**:
>    - Por seguridad estándar de los navegadores web entre dominios distintos, la app guarda localmente (en los dispositivos autorizados) el correo y contraseña de la alumna para tenerlos a un toque, y abre el enlace directo personalizado si la academia dispone de él vía API/registro.

---

### 1. Visión General y Concepto Central

- **Qué resuelve**: Garantiza inmediatez real para la alumna pagada —quien puede alternar entre su celular y computadora dentro de su hogar o país sin buscar correos ni contraseñas cada día— mientras protege al profesor frente a cuentas compartidas entre distintas personas o países.
- **Actores principales**:
  - **Alumna inscrita**: Valida su pase una vez por dispositivo (máx. 2), conserva guardadas sus credenciales de aula virtual y entra directo a sus talleres.
  - **Profesor / Administrador**: Accede con su clave protegida (con opción de recordar sus credenciales), carga alumnas y códigos de compra, guarda credenciales iniciales para las alumnas y monitorea las alertas de dispositivos/países.
  - **Visitante sin pase**: Visualiza la agenda pública y el recorrido de Pincelín, con invitación directa a inscribirse en la landing oficial.

---

### 2. Experiencia de Usuario y Diseño Visual

#### Flujos principales de usuario

1. **Visitante sin validación (Vitrina pública)**:
   - Muestra el programa completo de los 9 talleres, colaboradores, fechas y el camino navideño de Pincelín.
   - El acceso a clases y credenciales permanece cerrado con dos acciones claras: **"Validar mi inscripción"** y **"Inscribirme en la feria"**.

2. **Validación de alumna (Correo + Código de compra + Detección IP/País)**:
   - La alumna introduce su **correo electrónico** y **código único de compra**.
   - El servidor consulta la **IP pública real** y el **país** del solicitante (sin que el navegador pueda falsificarlos) y los envía junto con el identificador del dispositivo a Supabase.
   - **Caso exitoso (≤ 2 dispositivos y mismo país)**:
     - Autoriza el dispositivo, guarda su contraseña de `aulavirtual-premium.com` en el navegador autorizado (precargada por el admin o ingresada en esa primera activación) y desbloquea la tarjeta **"Tu puerta de acceso a clases"** con entrada directa y copia en un toque.
   - **Caso bloqueado (≥ 3 dispositivos o país diferente)**:
     - Rechaza el acceso de inmediato, registra la alerta en Supabase y muestra en pantalla un aviso explícito:
       > *"Acceso bloqueado por seguridad: esta alumna ha ingresado en X dispositivos distintos o desde ubicaciones incompatibles (ej. VE y US). Límite permitido: 2 dispositivos en un mismo país."*

3. **Apartado de Administrador (Protegido con clave y credenciales guardadas)**:
   - Botón discreto de **"Acceso Administrador"** (en el pie de página o modal dedicado).
   - Solicita **usuario/correo de administrador + clave maestra de acceso**, validada contra Supabase.
   - Incluye la casilla **"Guardar mis credenciales de administrador en este equipo"** para que el profesor conserve su acceso listo localmente (con opción de cerrar sesión y borrar credenciales cuando desee).
   - Dentro del panel administrativo puede:
     - Registrar o importar en bloque alumnas (correo, código único de compra, contraseña de aula virtual / enlace directo).
     - Ver el tablero de **Alertas de Acceso Compartido** (alumna, cantidad `X` de dispositivos, IPs/países detectados como `VE` vs `US`, fecha del intento).
     - **Restablecer dispositivos / ubicación** de una alumna legítima en un clic si cambió de teléfono o viajó.

#### Identidad visual y consistencia de marca

- **Dirección estética**: Editorial festiva cálida alineada a la 6ta Feria Territorio Canva.
- **Paleta cromática**: Fondo verde pino (`#2E4F35`), tarjetas marfil (`#FFFDF7` / `#FBF5E6`), bordes arena (`#E5DAC0`), acento principal carmesí navideño (`#A3363D`) y estados verificados en verde abeto (`#3F6B45`).
- **Tipografía y lectura**: `Playfair Display` para encabezados y `Montserrat` (`tabular-nums`) para códigos de compra, conteo de dispositivos e IPs.
- **Claridad de estados**: Todas las alertas de bloqueo y confirmaciones combinan color, icono de escudo/candado y texto descriptivo legible (contraste WCAG AA).

---

### 3. Decisiones Clave de Producto y Compromisos Técnicos

1. **Verificación de IP y País desde función serverless en Vercel (no desde el navegador)**:
   - *Decisión*: El cliente llamará a una ruta propia (`/api/verify-access`) hospedada en Vercel (con equivalente en servidor local para pruebas), la cual lee las cabeceras reales de red e IP (`x-forwarded-for`, `x-vercel-ip-country`, `x-vercel-ip-city`) antes de consultar a Supabase.
   - *Por qué*: Si la IP o el país se consultaran solo desde el navegador, un usuario avanzado podría alterarlos. Al leerlos en el servidor de Vercel y compararlos dentro de Supabase, el bloqueo entre EE. UU. y Venezuela es real y confiable.
   - *Equilibrio hogar vs. viaje*: Se permite cambiar entre habitación y cocina (misma IP y país) y entre Wi-Fi y datos móviles dentro del **mismo país**, manteniendo el límite de **2 dispositivos**. Solo un **país distinto** o un **3.er dispositivo** dispara el bloqueo y la alerta.

2. **Seguridad del Panel Administrador y credenciales guardadas**:
   - *Decisión*: La clave de administrador se verifica en Supabase mediante función segura (`RPC`) y emite un token temporal de sesión administrativa; opcionalmente, si el profesor marca *"Guardar credenciales"*, se almacenan en su navegador protegido para acceso inmediato, con botón visible para olvidar/cerrar sesión en equipos compartidos.
   - *Por qué*: Evita exponer contraseñas en el código fuente público de GitHub y da comodidad al administrador sin sacrificar seguridad en la nube.

3. **Inmediatez de acceso a clases sin exponer la lista completa de inscritos**:
   - *Decisión*: Todo intercambio entre navegador y base de datos usa funciones `RPC` puntuales en Supabase con políticas RLS cerradas al público general sobre la tabla de alumnas y dispositivos.

---

### 4. Arquitectura Técnica y Estrategia de Datos *(Referencia Técnica)*

#### Diagrama de arquitectura del sistema

```
┌────────────────────────────────────────────────────────────────────────────┐
│                        Navegador (Alumna o Administrador)                  │
│                                                                            │
│  ┌──────────────────────┐  ┌─────────────────────┐  ┌───────────────────┐  │
│  │   Vitrina Pública    │  │  Puerta de Clases   │  │   Panel Admin     │  │
│  │ • Agenda y Pincelín  │  │ • Email + Código    │  │ • Clave Admin     │  │
│  │ • Colaboradores      │  │ • Claves guardadas  │  │ • Guardar claves  │  │
│  │ • Venta oficial      │  │ • Alerta X equipos  │  │ • Alertas IP/País │  │
│  └──────────────────────┘  └──────────┬──────────┘  └─────────┬─────────┘  │
└───────────────────────────────────────┼───────────────────────┼────────────┘
                                        │                       │
┌───────────────────────────────────────▼───────────────────────▼────────────┐
│                  Capa Serverless en Vercel (/api/*)                        │
│  • Extrae IP pública real (x-forwarded-for) y País (x-vercel-ip-country)   │
│  • Reenvía solicitud firmada/validada hacia RPC de Supabase                │
└───────────────────────────────────────┬────────────────────────────────────┘
                                        │ HTTPS / RPC
┌───────────────────────────────────────▼────────────────────────────────────┐
│                            Base de Datos Supabase                          │
│                                                                            │
│  ┌─────────────────────────────┐      ┌─────────────────────────────────┐  │
│  │  enrolled_students          │      │  student_devices                │  │
│  │  • email, purchase_code     │─────▶│  • device_id, device_label      │  │
│  │  • classroom_password       │      │  • last_ip, country_code        │  │
│  │  • primary_country (ej. VE) │      │  • is_authorized                │  │
│  │  • max_devices = 2          │      └────────────────┬────────────────┘  │
│  └──────────────┬──────────────┘                       │                   │
│                 │                                      ▼                   │
│                 │                     ┌─────────────────────────────────┐  │
│                 └────────────────────▶│  device_access_alerts           │  │
│                                       │  • detected_devices_count (X)   │  │
│                                       │  • attempted_ip, country_code   │  │
│                                       │  • reason ('MAX_DEVICES' | 'GEO')│  │
│                                       └─────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │  admin_credentials (usuario admin + hash de clave verificada en RPC) │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────────────┘
```

#### Modelo de datos y reglas de validación

- **`enrolled_students`**:
  - `email`, `full_name`, `purchase_code`, `classroom_password` (opcional, precargada por admin), `classroom_url` (opcional), `primary_country` (se fija automáticamente en el primer ingreso verificado, ej. `VE`), `max_devices` (`2`), `is_active`.
- **`student_devices`**:
  - `student_id`, `device_id`, `device_label`, `ip_address`, `country_code`, `city`, `is_authorized`, `last_seen_at`.
- **`device_access_alerts`**:
  - `student_id`, `email`, `detected_devices_count`, `countries_seen` (arreglo de países detectados, ej. `["VE", "US"]`), `attempted_ip`, `attempted_country`, `reason`, `created_at`.
- **`admin_credentials`**:
  - `admin_email`, `access_key_hash`, `display_name`, verificada exclusivamente vía función RPC en servidor.

#### Regla exacta de evaluación en servidor (`verify_student_access`)

1. Verifica que `email` + `purchase_code` existan y estén activos.
2. Si `primary_country` está vacío, asigna el país del primer ingreso (`country_code`).
3. **Control geográfico**: Si el `country_code` actual difiere del `primary_country` autorizado (ej. `US` vs `VE`), bloquea inmediatamente, inserta alerta en `device_access_alerts` con `reason = 'COUNTRY_MISMATCH'` y devuelve el conteo total `X` de dispositivos + países detectados.
4. **Control de dispositivos (máx. 2)**:
   - Si el `device_id` ya está autorizado → actualiza `last_ip` y `last_seen_at`, y concede paso inmediato (soporta movimiento habitación → cocina o cambio de Wi-Fi a datos en el mismo país).
   - Si es un dispositivo nuevo y los dispositivos autorizados actuales son `< 2` → autoriza este 2.º dispositivo y concede paso.
   - Si ya existen `2` dispositivos autorizados y llega un 3.º → bloquea el acceso, registra alerta con `reason = 'MAX_DEVICES'` y devuelve el total `X` de dispositivos que han intentado ingresar.

#### Mapeo interactivo de componentes

- **Modal / Puerta de Alumna**: Alterna entre formulario de verificación (`Correo` + `Código de compra`), vista de **Acceso Listo** (credenciales guardadas localmente, botón de copiar en 1 toque y botón directo a la plataforma de clases) y **Tarjeta de Alerta de Bloqueo** (indicando cantidad de dispositivos `X` y diferencia geográfica).
- **Modal / Panel de Administrador**: Pantalla de ingreso con usuario + clave de acceso y casilla *"Guardar credenciales en este dispositivo"*; una vez dentro, pestañas limpias para:
  1. **Alumnas y Credenciales** (alta individual, carga masiva CSV y edición de clave/enlace de aula).
  2. **Alertas de Seguridad** (listado de cuentas bloqueadas con `X` dispositivos y países detectados + botón *"Restablecer dispositivos y país"*).
